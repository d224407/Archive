#!/system/bin/sh
while [ -z "$(getprop sys.boot_completed)" ]; do
	sleep 1
done

ANU() { [ -e "$1" ] && echo "$2" > "$1"; }
refresh_rate="$(dumpsys display | grep -Eo 'fps=[^.]+' | cut -f2 -d= | sort -n | uniq | tail -n1)"
[ -z "$refresh_rate" ] && refresh_rate=60
frame_time=$((1000000000/refresh_rate))
early_app_duration=$(awk -v ft="$frame_time" 'BEGIN {printf "%d", ft*1.95+1}')
early_sf_duration=$(awk -v ft="$frame_time" 'BEGIN {printf "%d", ft*1.48+1}')
early_gl_app_phase_offset=$(awk -v ft="$frame_time" 'BEGIN {printf "%d", -ft*2.8-1}')
early_phase_offset=$(awk -v ft="$frame_time" 'BEGIN {printf "%d", -ft*2.3-1}')
late_app_offset=$(awk -v ft="$frame_time" 'BEGIN {printf "%d", ft*0.1}')
late_sf_offset=$(awk -v ft="$frame_time" 'BEGIN {printf "%d", ft*0.15}')
total_ram="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
cpu_cores=$(grep -c ^processor /proc/cpuinfo)

STAN() {
    setprop debug.sf.early.app.duration "$early_app_duration"
    setprop debug.sf.earlyGl.app.duration "$early_app_duration"
    setprop debug.sf.early.sf.duration "$early_sf_duration"
    setprop debug.sf.earlyGl.sf.duration "$early_sf_duration"
    setprop debug.sf.early_app_phase_offset_ns "$early_gl_app_phase_offset"
    setprop debug.sf.high_fps_early_app_phase_offset_ns "$early_gl_app_phase_offset"
    setprop debug.sf.early_gl_app_phase_offset_ns "$early_gl_app_phase_offset"
    setprop debug.sf.early_gl_phase_offset_ns "$early_gl_app_phase_offset"
    setprop debug.sf.early_phase_offset_ns "$early_phase_offset"
    setprop debug.sf.high_fps_early_phase_offset_ns "$early_phase_offset"
    setprop debug.sf.high_fps_early_sf_phase_offset_ns "$early_phase_offset"
    setprop debug.sf.high_fps_late_sf_phase_offset_ns "$late_sf_offset"
    setprop debug.sf.high_fps_late_app_phase_offset_ns "$late_app_offset"
    setprop debug.sf.late.app.duration "$late_app_offset"
    setprop debug.sf.late.sf.duration "$late_sf_offset"
    setprop debug.sf.frame_rate_multiple_threshold "$refresh_rate"
    setprop debug.sf.use_phase_offsets_as_durations 1
    setprop debug.sf.predict_hwc_composition_strategy 1
    setprop debug.sf.no_vsyncs_on_screen_off true
    setprop debug.sf.multithreaded_present true
    setprop debug.sf.luma_sampling 0

    resetprop -n ro.surface_flinger.game_default_frame_rate_override "$refresh_rate"
    resetprop -n ro.surface_flinger.enable_adpf_cpu_hint true
    resetprop -n ro.surface_flinger.enable_present_time_offset true
    resetprop -n ro.surface_flinger.uclamp.min 256
    resetprop -n ro.surface_flinger.set_idle_timer_ms 40
    resetprop -n ro.surface_flinger.set_touch_timer_ms 60
    resetprop -n ro.surface_flinger.set_display_power_timer_ms 300

    if [ "$total_ram" -le 3072 ]; then
        setprop dalvik.vm.heapstartsize 12m
        setprop dalvik.vm.heapgrowthlimit 128m
        setprop dalvik.vm.heapsize 384m
        setprop dalvik.vm.heaptargetutilization 0.7
    elif [ "$total_ram" -le 4096 ]; then
        setprop dalvik.vm.heapstartsize 16m
        setprop dalvik.vm.heapgrowthlimit 192m
        setprop dalvik.vm.heapsize 512m
        setprop dalvik.vm.heaptargetutilization 0.75
    elif [ "$total_ram" -le 6144 ]; then
        setprop dalvik.vm.heapstartsize 24m
        setprop dalvik.vm.heapgrowthlimit 256m
        setprop dalvik.vm.heapsize 768m
        setprop dalvik.vm.heaptargetutilization 0.8
    elif [ "$total_ram" -le 8192 ]; then
        setprop dalvik.vm.heapstartsize 32m
        setprop dalvik.vm.heapgrowthlimit 384m
        setprop dalvik.vm.heapsize 1024m
        setprop dalvik.vm.heaptargetutilization 0.85
    elif [ "$total_ram" -le 12288 ]; then
        setprop dalvik.vm.heapstartsize 48m
        setprop dalvik.vm.heapgrowthlimit 512m
        setprop dalvik.vm.heapsize 1536m
        setprop dalvik.vm.heaptargetutilization 0.88
    else
        setprop dalvik.vm.heapstartsize 64m
        setprop dalvik.vm.heapgrowthlimit 768m
        setprop dalvik.vm.heapsize 2048m
        setprop dalvik.vm.heaptargetutilization 0.9
    fi

    setprop dalvik.vm.usejit true
    setprop dalvik.vm.usejitprofiles true
    setprop dalvik.vm.appimageformat lz4
    setprop dalvik.vm.dexopt-flags m=y,o=y,u=n
    setprop dalvik.vm.dex2oat-filter everything
    setprop dalvik.vm.systemuicompilerfilter everything
    setprop dalvik.vm.systemservercompilerfilter everything
    setprop pm.dexopt.bg-dexopt everything
    setprop pm.dexopt.install everything
    setprop pm.dexopt.shared everything

    if [ "$cpu_cores" -ge 8 ]; then
        setprop dalvik.vm.dex2oat-threads 8
        setprop dalvik.vm.image-dex2oat-threads 8
        setprop dalvik.vm.dex2oat-cpu-set 0-7
    elif [ "$cpu_cores" -ge 6 ]; then
        setprop dalvik.vm.dex2oat-threads 6
        setprop dalvik.vm.image-dex2oat-threads 6
        setprop dalvik.vm.dex2oat-cpu-set 0-5
    else
        setprop dalvik.vm.dex2oat-threads 4
        setprop dalvik.vm.image-dex2oat-threads 4
        setprop dalvik.vm.dex2oat-cpu-set 0-3
    fi

    ANU /dev/stune/schedtune.boost 0
    ANU /dev/stune/schedtune.prefer_idle 0
    ANU /dev/stune/top-app/schedtune.boost 90
    ANU /dev/stune/top-app/schedtune.prefer_idle 1
    ANU /dev/stune/foreground/schedtune.boost 70
    ANU /dev/stune/foreground/schedtune.prefer_idle 1
    ANU /dev/stune/background/schedtune.boost 15
    ANU /dev/stune/background/schedtune.prefer_idle 0

    ANU /sys/module/ged/parameters/gx_dfps "$refresh_rate"
    ANU /sys/module/ged/parameters/boost_gpu_enable 1
    ANU /sys/module/ged/parameters/gpu_dvfs_enable 1
    ANU /sys/module/ged/parameters/enable_cpu_boost 1
    ANU /sys/module/ged/parameters/enable_gpu_boost 1
    ANU /sys/module/ged/parameters/boost_extra 1
    ANU /sys/module/ged/parameters/gx_game_mode 1
    ANU /sys/module/ged/parameters/gx_force_cpu_boost 1
    ANU /sys/module/ged/parameters/gx_frc_mode 1

    for e in mmcblk0 sda sdb sdc; do
        f="/sys/block/$e/queue"
        ANU "$f/scheduler" noop
        ANU "$f/add_random" 0
        ANU "$f/iostats" 0
        ANU "$f/nomerges" 2
        ANU "$f/rotational" 0
        ANU "$f/rq_affinity" 2
        ANU "$f/nr_requests" 128
        ANU "$f/read_ahead_kb" 128
    done

    setprop persist.sys.ui.hw true
    setprop debug.composition.type gpu
    setprop touch.pressure.calibration amplitude
    setprop touch.pressure.scale 0.015
    setprop touch.size.scale 0.009
    setprop touch.size.calibration diameter
    setprop touch.size.isSummed 0
    setprop touch.size.bias -0.4

    settings put global window_animation_scale 0.2
    settings put global transition_animation_scale 0.2
    settings put global animator_duration_scale 0.2

    settings put global block_untrusted_touches 0
    settings put secure multi_press_timeout 170
    settings put secure long_press_timeout 170
}

STAN