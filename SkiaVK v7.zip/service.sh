#!/system/bin/sh

until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 7
done

Y() { [ -e "$1" ] && echo "$2" > "$1"; }
N() { resetprop -n "$1" "$2"; }

N "debug.renderengine.vulkan" "true"
N "debug.renderengine.backend" "skiavkthreaded"
N "debug.renderengine.skia_atrace_enabled" "false"
N "debug.hwui.renderer" "skiavk"
N "debug.hwui.level" "0"
N "debug.hwui.skia_tracing_enabled" "false"
N "debug.hwui.skia_use_perfetto_track_events" "false"
N "debug.hwui.render_dirty_regions" "false"
N "debug.hwui.use_gpu_pixel_buffers" "true"
N "debug.hwui.use_buffer_age" "true"
N "debug.hwui.skip_empty_damage" "true"
N "debug.hwui.skip_eglmanager_telemetry" "true"
N "debug.sf.auto_latch_unsignaled" "true"
N "debug.sf.multithreaded_present" "true"
N "debug.sf.disable_client_composition_cache" "1"
N "debug.graphics.game_default_frame_rate.disabled" "true"

#schedtune boost by zaidan
Y /dev/stune/schedtune.boost 7
Y /dev/stune/schedtune.preferidle 1
Y /dev/stune/background/schedtune.boost 2
Y /dev/stune/background/schedtune.preferidle 1
Y /dev/stune/foreground/schedtune.boost 8
Y /dev/stune/foreground/schedtune.preferidle 0
Y /dev/stune/top-app/schedtune.boost 25
Y /dev/stune/top-app/schedtune.preferidle 0