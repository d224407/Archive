#!/system/bin/sh
MODDIR=${0%/*}

while [ -z "$(getprop sys.boot_completed)" ]; do
    sleep 10
done

PingPimp --boot
ip route flush cache 2>/dev/null